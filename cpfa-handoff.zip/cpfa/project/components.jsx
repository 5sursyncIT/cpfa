/* CPFA — Shared components: Logo, Nav, Footer, OrbitGraphic */

const { useState, useEffect, useRef } = React;

/* ============================================================
   LogoMark — recreates the orbital motif from the source logo:
   orange ellipse (sphere) crossed by a navy elliptical ring.
   ============================================================ */
function LogoMark({ size = 38 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="lm-sphere" cx="35%" cy="35%" r="75%">
          <stop offset="0%" stopColor="oklch(72% 0.18 50)" />
          <stop offset="55%" stopColor="oklch(58% 0.18 40)" />
          <stop offset="100%" stopColor="oklch(28% 0.08 35)" />
        </radialGradient>
      </defs>
      {/* Back half of ring */}
      <path d="M 12 50 a 38 12 -8 0 1 76 0" stroke="var(--navy)" strokeWidth="3.5" fill="none" />
      {/* Sphere */}
      <ellipse cx="50" cy="50" rx="22" ry="34" fill="url(#lm-sphere)" />
      {/* Highlight */}
      <ellipse cx="60" cy="48" rx="5" ry="3.5" fill="white" stroke="black" strokeWidth="0.8" />
      {/* Front half of ring */}
      <path d="M 12 50 a 38 12 -8 0 0 76 0" stroke="var(--navy)" strokeWidth="3.5" fill="none" />
    </svg>
  );
}

/* OrbitGraphic — large decorative version for hero */
function OrbitGraphic() {
  return (
    <svg viewBox="0 0 800 800" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="og-sphere" cx="32%" cy="32%" r="80%">
          <stop offset="0%" stopColor="oklch(78% 0.16 50)" />
          <stop offset="50%" stopColor="oklch(58% 0.18 40)" />
          <stop offset="100%" stopColor="oklch(22% 0.08 30)" />
        </radialGradient>
      </defs>
      <ellipse cx="400" cy="400" rx="340" ry="120" stroke="var(--navy)" strokeWidth="2" opacity="0.35" />
      <ellipse cx="400" cy="400" rx="280" ry="95" stroke="var(--navy)" strokeWidth="2" opacity="0.5" transform="rotate(-12 400 400)" />
      <ellipse cx="400" cy="400" rx="220" ry="70" stroke="var(--navy)" strokeWidth="2" opacity="0.7" transform="rotate(18 400 400)" />
      <ellipse cx="400" cy="400" rx="175" ry="265" fill="url(#og-sphere)" />
    </svg>
  );
}

/* ============================================================
   TopNav
   ============================================================ */
function TopNav({ route, onNav }) {
  const links = [
    { id: 'home', label: 'Accueil' },
    { id: 'formations', label: 'Formations' },
    { id: 'seminaires', label: 'Séminaires' },
    { id: 'bibliotheque', label: 'Bibliothèque' },
    { id: 'concours', label: 'Concours' },
    { id: 'about', label: 'À propos' },
  ];
  return (
    <nav className="topnav">
      <div className="container topnav-inner">
        <a className="brand" onClick={() => onNav('home')}>
          <div className="brand-mark">
            <LogoMark size={38} />
          </div>
          <div className="brand-text">
            <span className="brand-name">CPFA</span>
            <span className="brand-tag">Centre de Formation · Assurance</span>
          </div>
        </a>
        <div className="nav-links">
          {links.map(l => (
            <a key={l.id}
               className={"nav-link" + (route === l.id ? " active" : "")}
               onClick={() => onNav(l.id)}>
              {l.label}
            </a>
          ))}
        </div>
        <div className="row gap-2">
          <button className="btn btn-ghost btn-sm" onClick={() => onNav('member')}>
            Espace abonné
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => onNav('formations')}>
            S'inscrire
            <span className="arrow">→</span>
          </button>
        </div>
      </div>
    </nav>
  );
}

/* ============================================================
   Footer
   ============================================================ */
function Footer({ onNav }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="row gap-3" style={{alignItems: 'center', marginBottom: 16}}>
              <LogoMark size={42} />
              <div className="brand-text">
                <span className="brand-name" style={{color: 'white'}}>CPFA</span>
                <span className="brand-tag" style={{color: 'oklch(70% 0.02 258)'}}>Dakar · Sénégal</span>
              </div>
            </div>
            <p className="fs-14" style={{color: 'oklch(80% 0.01 80)', lineHeight: 1.5, maxWidth: 320}}>
              Premier centre de référence au Sénégal en matière de formation
              dans les métiers de l'assurance.
            </p>
          </div>
          <div>
            <h5>Programmes</h5>
            <ul>
              <li onClick={() => onNav('formations')}>Cursus diplômants</li>
              <li onClick={() => onNav('formations')}>Certifications professionnelles</li>
              <li onClick={() => onNav('seminaires')}>Séminaires & masterclass</li>
              <li onClick={() => onNav('concours')}>Concours d'entrée</li>
              <li onClick={() => onNav('formations')}>Formations sur mesure</li>
            </ul>
          </div>
          <div>
            <h5>Ressources</h5>
            <ul>
              <li onClick={() => onNav('bibliotheque')}>Bibliothèque</li>
              <li>Publications & études</li>
              <li>Veille réglementaire</li>
              <li>Annuaire alumni</li>
              <li onClick={() => onNav('member')}>Espace abonné</li>
            </ul>
          </div>
          <div>
            <h5>Contact</h5>
            <ul>
              <li>Sicap Sacré-Cœur 3</li>
              <li>BP 3308 — Dakar, Sénégal</li>
              <li>+221 33 824 00 00</li>
              <li>contact@cpfa.sn</li>
            </ul>
            <div className="row gap-2" style={{marginTop: 16}}>
              <span className="pill" style={{borderColor: 'oklch(35% 0.04 258)', color: 'oklch(80% 0.01 80)'}}>FR</span>
              <span className="pill" style={{borderColor: 'oklch(35% 0.04 258)', color: 'oklch(60% 0.02 258)'}}>EN</span>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 CPFA · Agréé par le Ministère des Finances</span>
          <span>Conçu à Dakar · Fait en orbite</span>
        </div>
      </div>
    </footer>
  );
}

/* ============================================================
   Marquee — ticker bar
   ============================================================ */
function Marquee() {
  const items = [
    "Concours d'entrée 2026 · Inscriptions ouvertes",
    "Nouveau : Certificat Bancassurance",
    "Séminaire CIMA · 14 juin",
    "Bibliothèque · 3 200 références",
    "Partenariat Institut des Actuaires",
  ];
  const all = [...items, ...items];
  return (
    <div className="full-bleed-bar">
      <div className="marquee">
        {all.map((it, i) => <span key={i}>{it}</span>)}
      </div>
    </div>
  );
}

/* Export to window so other Babel files can pick them up */
Object.assign(window, {
  LogoMark, OrbitGraphic, TopNav, Footer, Marquee,
});
