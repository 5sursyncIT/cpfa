/* CPFA — App shell, router, Contact page, Tweaks */

const { useState: useAppState, useEffect: useAppEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "orange",
  "density": "regular",
  "theme": "light",
  "headingStyle": "serif-italic"
}/*EDITMODE-END*/;

/* ============================================================
   Router
   ============================================================ */
function App() {
  const [route, setRoute] = useAppState({ name: 'home', param: null });
  const [editMode, setEditMode] = useAppState(false);
  const [t, setT] = useAppState(TWEAK_DEFAULTS);

  useAppEffect(() => {
    function onMsg(e) {
      if (e.data?.type === '__activate_edit_mode') setEditMode(true);
      if (e.data?.type === '__deactivate_edit_mode') setEditMode(false);
    }
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  // Apply theme & density to root
  useAppEffect(() => {
    document.documentElement.dataset.theme = t.theme;
    document.documentElement.dataset.density = t.density;
    // Update accent if needed
    const accentMap = {
      orange: { o: 'oklch(64% 0.18 45)', od: 'oklch(54% 0.18 38)', os: 'oklch(92% 0.04 50)' },
      teal:   { o: 'oklch(64% 0.12 180)', od: 'oklch(48% 0.12 180)', os: 'oklch(92% 0.03 180)' },
      red:    { o: 'oklch(58% 0.2 25)', od: 'oklch(46% 0.2 25)', os: 'oklch(94% 0.04 25)' },
      gold:   { o: 'oklch(72% 0.14 80)', od: 'oklch(56% 0.14 80)', os: 'oklch(94% 0.04 80)' },
    };
    const a = accentMap[t.accent] || accentMap.orange;
    const root = document.documentElement;
    root.style.setProperty('--orange', a.o);
    root.style.setProperty('--orange-deep', a.od);
    root.style.setProperty('--orange-soft', a.os);
  }, [t]);

  function setTweak(key, val) {
    if (typeof key === 'object') {
      const next = { ...t, ...key };
      setT(next);
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: key }, '*');
    } else {
      const next = { ...t, [key]: val };
      setT(next);
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [key]: val } }, '*');
    }
  }

  function nav(name, param = null) {
    setRoute({ name, param });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  const isAdmin = route.name === 'admin';
  return (
    <div data-screen-label={"CPFA · " + route.name}>
      {!isAdmin && <TopNav route={route.name} onNav={nav} />}
      {route.name === 'home' && <Home onNav={nav} />}
      {route.name === 'formations' && <Formations onNav={nav} />}
      {route.name === 'formation-detail' && <FormationDetail id={route.param} onNav={nav} />}
      {route.name === 'seminaires' && <Seminaires onNav={nav} />}
      {route.name === 'bibliotheque' && <Bibliotheque onNav={nav} />}
      {route.name === 'concours' && <Concours onNav={nav} />}
      {route.name === 'about' && <About onNav={nav} />}
      {route.name === 'contact' && <Contact onNav={nav} />}
      {route.name === 'member' && <Member onNav={nav} />}
      {route.name === 'admin' && <AdminDashboard onNav={nav} />}
      {!isAdmin && <Footer onNav={nav} />}
      {!isAdmin && (
        <button
          onClick={() => nav('admin')}
          style={{
            position: 'fixed', bottom: 20, left: 20, zIndex: 40,
            padding: '8px 14px', borderRadius: 999,
            background: 'var(--ink)', color: 'var(--bg)', border: 'none',
            fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.06em',
            textTransform: 'uppercase', cursor: 'pointer', opacity: 0.85,
          }}
        >⚙ Aperçu admin</button>
      )}
      {editMode && (
        <TweaksPanel onClose={() => { setEditMode(false); window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*'); }}>
          <TweakSection title="Couleur d'accent">
            <TweakColor
              label="Accent"
              value={t.accent}
              onChange={v => setTweak('accent', v)}
              options={[
                { value: 'orange', color: '#D2581F' },
                { value: 'gold', color: '#C18C2A' },
                { value: 'teal', color: '#1F8E8E' },
                { value: 'red', color: '#C13C2A' },
              ]}
            />
          </TweakSection>
          <TweakSection title="Densité">
            <TweakRadio
              value={t.density}
              onChange={v => setTweak('density', v)}
              options={[
                { value: 'compact', label: 'Compact' },
                { value: 'regular', label: 'Confort' },
                { value: 'spacious', label: 'Aéré' },
              ]}
            />
          </TweakSection>
          <TweakSection title="Thème">
            <TweakRadio
              value={t.theme}
              onChange={v => setTweak('theme', v)}
              options={[
                { value: 'light', label: 'Clair' },
                { value: 'dark', label: 'Sombre' },
              ]}
            />
          </TweakSection>
          <TweakSection title="Navigation rapide">
            <div style={{display: 'flex', flexDirection: 'column', gap: 6}}>
              {[
                ['home', 'Accueil'], ['formations', 'Catalogue'],
                ['formation-detail', 'Détail formation'], ['bibliotheque', 'Bibliothèque'],
                ['seminaires', 'Séminaires'], ['concours', 'Concours'],
                ['member', 'Espace abonné'], ['about', 'À propos'],
                ['contact', 'Contact'], ['admin', 'Admin'],
              ].map(([id, label]) => (
                <button key={id}
                  onClick={() => nav(id, id === 'formation-detail' ? 'mba-assurance' : null)}
                  style={{
                    padding: '8px 12px', textAlign: 'left',
                    background: route.name === id ? 'var(--ink)' : 'transparent',
                    color: route.name === id ? 'var(--bg)' : 'var(--ink)',
                    border: '1px solid var(--line)', borderRadius: 6,
                    fontFamily: 'var(--sans)', fontSize: 13, cursor: 'pointer',
                  }}
                >{label}</button>
              ))}
            </div>
          </TweakSection>
        </TweaksPanel>
      )}
    </div>
  );
}

/* ============================================================
   CONTACT page (lightweight)
   ============================================================ */
function Contact({ onNav }) {
  const [sent, setSent] = useAppState(false);
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>Contact</span></div>
        <h1>Une question, un projet,<br/><em className="italic-emph">une candidature ?</em></h1>
      </div>
      <div className="container" style={{paddingBottom: 96}}>
        <div className="row gap-7" style={{display: 'grid', gridTemplateColumns: '1.2fr 1fr'}}>
          <div className="card" style={{padding: 32}}>
            {sent ? (
              <div className="col gap-4" style={{textAlign: 'center', padding: '32px 0'}}>
                <div style={{fontFamily: 'var(--serif)', fontSize: 56, lineHeight: 1, color: 'var(--orange-deep)'}}>✓</div>
                <h3>Message reçu</h3>
                <p className="fs-15 text-mid">Notre équipe vous répondra sous 48 heures ouvrées.</p>
                <button className="btn btn-ghost" onClick={() => setSent(false)} style={{alignSelf: 'center'}}>Envoyer un autre message</button>
              </div>
            ) : (
              <form className="col gap-4" onSubmit={e => { e.preventDefault(); setSent(true); }}>
                <div className="row gap-3">
                  <div style={{flex: 1}}>
                    <label className="label">Prénom</label>
                    <input className="input" required />
                  </div>
                  <div style={{flex: 1}}>
                    <label className="label">Nom</label>
                    <input className="input" required />
                  </div>
                </div>
                <div>
                  <label className="label">Email</label>
                  <input className="input" type="email" required />
                </div>
                <div>
                  <label className="label">Objet</label>
                  <select className="select" defaultValue="formations">
                    <option value="formations">Information sur les formations</option>
                    <option>Inscription au concours</option>
                    <option>Partenariat entreprise</option>
                    <option>Bibliothèque</option>
                    <option>Presse</option>
                    <option>Autre</option>
                  </select>
                </div>
                <div>
                  <label className="label">Message</label>
                  <textarea className="textarea" rows={5} placeholder="Précisez votre demande…" required></textarea>
                </div>
                <button className="btn btn-primary btn-lg" type="submit" style={{alignSelf: 'start'}}>
                  Envoyer le message <span className="arrow">→</span>
                </button>
              </form>
            )}
          </div>
          <div className="col gap-5">
            <div className="card">
              <div className="label">Adresse</div>
              <p className="fs-15" style={{marginTop: 8, lineHeight: 1.45}}>
                Sicap Sacré-Cœur 3<br/>
                Avenue Bourguiba prolongée<br/>
                BP 3308 — Dakar, Sénégal
              </p>
            </div>
            <div className="card">
              <div className="label">Standard</div>
              <p className="fs-15" style={{marginTop: 8, lineHeight: 1.45}}>
                +221 33 824 00 00<br/>
                Lun-Ven · 8h30 — 17h30
              </p>
            </div>
            <div className="card">
              <div className="label">Email</div>
              <p className="fs-15" style={{marginTop: 8, lineHeight: 1.45}}>
                contact@cpfa.sn — général<br/>
                admissions@cpfa.sn — concours<br/>
                bibliotheque@cpfa.sn — fonds
              </p>
            </div>
            <div className="card" style={{background: 'var(--ink)', color: 'var(--bg)', borderColor: 'transparent'}}>
              <div className="label" style={{color: 'oklch(70% 0.02 80)'}}>Vous êtes une entreprise ?</div>
              <h4 style={{color: 'var(--bg)', margin: '12px 0', fontSize: 24}}>Concevons une formation sur mesure pour vos équipes.</h4>
              <button className="btn" style={{background: 'var(--orange)', color: 'white'}}>Découvrir le programme corporate <span className="arrow">→</span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { App, Contact });

/* Mount */
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
