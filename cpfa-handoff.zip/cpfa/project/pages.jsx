/* CPFA — Pages module: Home, Formations, FormationDetail, Seminaires, Concours, About, Contact */

const { useState: usePagesState, useEffect: usePagesEffect } = React;

/* ============================================================
   DATA
   ============================================================ */
const FORMATIONS = [
  {
    id: 'mba-assurance', title: "MBA en Management de l'Assurance", category: "Cursus diplômant",
    duration: "24 mois", level: "Bac+5", price: "3 500 000 FCFA", cover: 'navy',
    seats: 28, rating: 4.8, sessions: "Octobre 2026 · Mars 2027",
    desc: "Programme phare formant les futurs cadres dirigeants des compagnies d'assurance et de réassurance en Afrique de l'Ouest."
  },
  {
    id: 'licence-pro', title: "Licence Professionnelle en Assurance", category: "Cursus diplômant",
    duration: "12 mois", level: "Bac+3", price: "1 200 000 FCFA", cover: 'orange',
    seats: 60, rating: 4.7, sessions: "Octobre 2026",
    desc: "Formation accélérée pour techniciens souhaitant accéder aux fonctions de souscription et gestion de sinistres."
  },
  {
    id: 'cert-bancassurance', title: "Certificat en Bancassurance", category: "Certification",
    duration: "6 mois", level: "Pro", price: "850 000 FCFA", cover: 'cream',
    seats: 32, rating: 4.9, sessions: "Septembre 2026",
    desc: "Conçu avec la BCEAO. Maîtriser les produits hybrides bancaire-assurance et la conformité CIMA."
  },
  {
    id: 'cert-actuariat', title: "Initiation à l'Actuariat", category: "Certification",
    duration: "9 mois", level: "Bac+4", price: "1 450 000 FCFA", cover: 'ink',
    seats: 24, rating: 4.6, sessions: "Janvier 2027",
    desc: "Fondamentaux mathématiques, modélisation du risque et tables de mortalité. Préparatoire IA."
  },
  {
    id: 'sem-sinistres', title: "Gestion des Sinistres Auto & IRD", category: "Séminaire",
    duration: "5 jours", level: "Pro", price: "320 000 FCFA", cover: 'navy',
    seats: 22, rating: 4.5, sessions: "14–18 juin · 12–16 sept",
    desc: "Cas pratiques sur la circulaire CIMA 2024, expertise contradictoire, recours subrogatoire."
  },
  {
    id: 'cert-microassurance', title: "Microassurance & Inclusion", category: "Certification",
    duration: "4 mois", level: "Pro", price: "550 000 FCFA", cover: 'orange',
    seats: 40, rating: 4.7, sessions: "Novembre 2026",
    desc: "Concevoir des produits accessibles aux populations rurales et au secteur informel ouest-africain."
  },
];

const FORMATION_CATEGORIES = ["Tout", "Cursus diplômant", "Certification", "Séminaire", "Sur mesure"];

const BOOKS = [
  { title: "Traité de Droit des Assurances CIMA", author: "Mamadou Diop", year: 2023, status: "dispo", cover: 'navy' },
  { title: "Actuariat Vie en Pratique", author: "F. Planchet", year: 2022, status: "emprunte", cover: 'orange' },
  { title: "Microassurance en Afrique", author: "BCEAO / ILO", year: 2024, status: "dispo", cover: 'cream' },
  { title: "Réassurance non-vie", author: "Klein & Sow", year: 2021, status: "dispo", cover: 'ink' },
  { title: "Solvabilité II", author: "C. Bellando", year: 2023, status: "dispo", cover: 'olive' },
  { title: "Bancassurance UEMOA", author: "A. Diallo", year: 2024, status: "dispo", cover: 'orange' },
  { title: "Sinistres Construction", author: "M. Faye", year: 2022, status: "emprunte", cover: 'navy' },
  { title: "Risk Management Africain", author: "Kane / Touré", year: 2023, status: "dispo", cover: 'cream' },
  { title: "Tables de mortalité TF/TH", author: "INED-CIPRES", year: 2024, status: "dispo", cover: 'ink' },
  { title: "Code des assurances annoté", author: "Édition 2025", year: 2025, status: "dispo", cover: 'olive' },
];

const TESTIMONIALS = [
  { quote: "Le CPFA m'a ouvert les portes de la direction technique d'une grande compagnie panafricaine. Les cas pratiques étaient redoutablement réalistes.", name: "Aïssatou Ndiaye", role: "Directrice Technique · NSIA Assurances" },
  { quote: "Ce que j'ai apprécié, c'est la rigueur académique alliée à une lecture profonde du contexte ouest-africain. C'est rare.", name: "Cheikh A. Bâ", role: "Inspecteur · Direction des Assurances" },
  { quote: "La bibliothèque seule justifie l'inscription. Aucun autre fonds documentaire spécialisé ne s'en approche dans la sous-région.", name: "Marie-Louise Sagna", role: "Doctorante · UCAD" },
];

const SEMINARS = [
  { day: "14", month: "Juin", title: "Réforme CIMA 2026 : ce qui change pour les assureurs", desc: "Décryptage des nouveaux ratios prudentiels et de l'agrément électronique.", duration: "2 jours", seats: "32 places · 18 restantes", price: "180 000 FCFA" },
  { day: "27", month: "Juin", title: "Masterclass — Souscription corporate IRD", desc: "Cas Total, Sonatel, BOAD : tarifer un programme complexe en réassurance facultative.", duration: "1 journée", seats: "20 places · COMPLET", price: "120 000 FCFA" },
  { day: "08", month: "Juil", title: "Workshop Solvabilité — modélisation actuarielle", desc: "Atelier pratique sur Excel + R, animé par Frédéric Planchet (ISFA Lyon).", duration: "3 jours", seats: "16 places · 4 restantes", price: "350 000 FCFA" },
  { day: "22", month: "Juil", title: "Bancassurance et inclusion financière", desc: "Co-organisé avec la BCEAO. Focus sur les produits microfinance + assurance.", duration: "2 jours", seats: "40 places · 22 restantes", price: "200 000 FCFA" },
  { day: "12", month: "Sept", title: "Forum panafricain de la réassurance", desc: "Édition 2026. CICA-Re, Africa-Re, Continental Re. Networking + tables rondes.", duration: "3 jours", seats: "Sur invitation", price: "Gratuit · partenaires" },
];

/* ============================================================
   HOME
   ============================================================ */
function Home({ onNav }) {
  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="hero-grid">
            <div>
              <span className="eyebrow" style={{marginBottom: 24, display: 'inline-flex'}}>
                Promotion 2026 · Inscriptions ouvertes
              </span>
              <h1 className="hero-headline">
                Former l'<span className="accent">orbite</span><br/>
                de l'assurance<br/>
                ouest-africaine.
              </h1>
            </div>
            <div className="hero-meta">
              <p>
                Le CPFA est l'<em>institut de référence au Sénégal</em> pour les
                métiers de l'assurance, de la réassurance et de l'actuariat.
                Trente ans à former les cadres techniques et dirigeants de la zone CIMA.
              </p>
              <div className="row gap-3">
                <button className="btn btn-primary btn-lg" onClick={() => onNav('formations')}>
                  Catalogue des formations
                  <span className="arrow">→</span>
                </button>
                <button className="btn btn-ghost btn-lg" onClick={() => onNav('about')}>
                  Découvrir l'institut
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="hero-orbit"><OrbitGraphic /></div>
      </section>

      <Marquee />

      {/* Stats */}
      <div className="container">
        <div className="stat-row">
          <div className="stat">
            <div className="stat-value">30<sup>ans</sup></div>
            <div className="stat-label">Au service du secteur</div>
          </div>
          <div className="stat">
            <div className="stat-value">4 200<sup>+</sup></div>
            <div className="stat-label">Diplômés actifs</div>
          </div>
          <div className="stat">
            <div className="stat-value">14</div>
            <div className="stat-label">Pays d'Afrique représentés</div>
          </div>
          <div className="stat">
            <div className="stat-value">96<sup>%</sup></div>
            <div className="stat-label">Taux d'insertion 12 mois</div>
          </div>
        </div>
      </div>

      {/* Formations preview */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow" style={{marginBottom: 16}}>Programmes phares</span>
              <h2>Six cursus pour <em className="italic-emph">six trajectoires</em><br/>de carrière dans l'assurance.</h2>
            </div>
            <button className="btn btn-ghost" onClick={() => onNav('formations')}>
              Voir le catalogue complet <span className="arrow">→</span>
            </button>
          </div>
          <div className="formations-grid">
            {FORMATIONS.slice(0, 3).map(f => (
              <FormationCard key={f.id} f={f} onClick={() => onNav('formation-detail', f.id)} />
            ))}
          </div>
        </div>
      </section>

      {/* Bibliothèque teaser */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow" style={{marginBottom: 16}}>Bibliothèque spécialisée</span>
              <h2>3 200 ouvrages, mémoires et<br/>études — accès aux abonnés.</h2>
            </div>
            <button className="btn btn-ghost" onClick={() => onNav('bibliotheque')}>
              Explorer le fonds <span className="arrow">→</span>
            </button>
          </div>
          <div className="book-grid">
            {BOOKS.slice(0, 5).map((b, i) => <Book key={i} b={b} />)}
          </div>
        </div>
      </section>

      {/* Témoignages */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow" style={{marginBottom: 16}}>Voix d'alumni</span>
              <h2>Ils ont étudié au CPFA<br/><em className="italic-emph">— et l'ont prouvé.</em></h2>
            </div>
          </div>
          <div className="quote-grid">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="quote-card">
                <div style={{fontSize: 28, color: 'var(--orange)', fontFamily: 'var(--serif)', lineHeight: 0}}>"</div>
                <p className="quote-text">{t.quote}</p>
                <div className="quote-author">
                  <div className="quote-avatar">{t.name.split(' ').map(p => p[0]).join('').slice(0,2)}</div>
                  <div>
                    <div className="quote-name">{t.name}</div>
                    <div className="quote-role">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA strip */}
      <section className="section" style={{paddingBottom: 0, borderTop: 'none'}}>
        <div className="container">
          <div className="concours-card">
            <div>
              <span className="eyebrow" style={{marginBottom: 16}}>Concours d'entrée 2026</span>
              <div className="concours-headline">
                Le concours<br/>
                <em className="italic-emph">ferme dans</em>
              </div>
              <Countdown />
              <div className="row gap-3">
                <button className="btn btn-orange btn-lg" onClick={() => onNav('concours')}>
                  Préparer mon dossier <span className="arrow">→</span>
                </button>
                <button className="btn btn-ghost btn-lg">Télécharger les annales</button>
              </div>
            </div>
            <div>
              <p className="fs-17 text-mid" style={{lineHeight: 1.5}}>
                Le concours d'entrée au MBA et à la Licence Professionnelle est ouvert aux
                titulaires d'un diplôme reconnu par le CAMES. Quatre épreuves :
                culture économique, mathématiques financières, anglais des affaires
                et entretien de motivation.
              </p>
              <div className="divider" style={{margin: '24px 0'}}></div>
              <div className="col gap-3">
                <div className="row" style={{justifyContent: 'space-between'}}>
                  <span className="text-soft fs-13">Dépôt en ligne</span>
                  <span className="mono fs-13">jusqu'au 30 août 2026</span>
                </div>
                <div className="row" style={{justifyContent: 'space-between'}}>
                  <span className="text-soft fs-13">Épreuves écrites</span>
                  <span className="mono fs-13">12 septembre 2026</span>
                </div>
                <div className="row" style={{justifyContent: 'space-between'}}>
                  <span className="text-soft fs-13">Résultats</span>
                  <span className="mono fs-13">25 septembre 2026</span>
                </div>
                <div className="row" style={{justifyContent: 'space-between'}}>
                  <span className="text-soft fs-13">Frais de dossier</span>
                  <span className="mono fs-13">25 000 FCFA</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Countdown() {
  // Static demo countdown
  return (
    <div className="countdown">
      {[{n: '128', l: 'Jours'}, {n: '14', l: 'Heures'}, {n: '32', l: 'Minutes'}, {n: '08', l: 'Secondes'}].map((c, i) => (
        <div key={i} className="countdown-cell">
          <div className="countdown-num">{c.n}</div>
          <div className="countdown-label">{c.l}</div>
        </div>
      ))}
    </div>
  );
}

function FormationCard({ f, onClick }) {
  return (
    <div className={"formation-card"} onClick={onClick}>
      <div className={"formation-cover formation-cover-" + f.cover}>
        <span className="pill">{f.category}</span>
      </div>
      <h4>{f.title}</h4>
      <p className="fs-14 text-mid" style={{lineHeight: 1.45}}>{f.desc}</p>
      <div className="meta">
        <span>{f.duration} · {f.level}</span>
        <span>{f.price}</span>
      </div>
    </div>
  );
}

function Book({ b }) {
  return (
    <div className="book">
      <div className={"book-cover " + b.cover}>
        <div className="book-author-on-cover">{b.author}</div>
        <div className="book-title-on-cover">{b.title}</div>
      </div>
      <div className="book-meta">
        <span className="title fs-13" style={{flex: 1, lineHeight: 1.3}}>{b.title}</span>
        <span className={"status " + b.status}>{b.status === 'dispo' ? 'Dispo' : 'Sortie'}</span>
      </div>
    </div>
  );
}

/* ============================================================
   FORMATIONS — catalogue
   ============================================================ */
function Formations({ onNav }) {
  const [cat, setCat] = usePagesState("Tout");
  const filtered = cat === "Tout" ? FORMATIONS : FORMATIONS.filter(f => f.category === cat);
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>Formations</span></div>
        <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', gap: 32}}>
          <h1 style={{fontSize: 'clamp(48px, 6vw, 84px)'}}>
            Le <em className="italic-emph">catalogue</em><br/>2026 — 2027.
          </h1>
          <p className="fs-17 text-mid" style={{maxWidth: 380, paddingBottom: 12}}>
            Six programmes diplômants, certifications professionnelles, séminaires courts
            et formations sur mesure pour vos équipes.
          </p>
        </div>
      </div>
      <div className="container">
        <div className="filter-bar">
          {FORMATION_CATEGORIES.map(c => (
            <button key={c}
              className={"filter-chip" + (c === cat ? " active" : "")}
              onClick={() => setCat(c)}>
              {c}
            </button>
          ))}
          <div style={{flex: 1}}></div>
          <input className="input" placeholder="Rechercher un programme…" style={{maxWidth: 280}} />
        </div>
        <div className="formations-grid" style={{marginBottom: 96}}>
          {filtered.map(f => (
            <FormationCard key={f.id} f={f} onClick={() => onNav('formation-detail', f.id)} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   FORMATION DETAIL + Inscription modal
   ============================================================ */
function FormationDetail({ id, onNav }) {
  const f = FORMATIONS.find(f => f.id === id) || FORMATIONS[0];
  const [open, setOpen] = usePagesState(false);
  const modules = [
    { num: "M01", title: "Cadre juridique CIMA et droit des assurances", desc: "Sources, autorité de contrôle, contentieux. Code CIMA annoté.", h: "48h" },
    { num: "M02", title: "Économie de l'assurance & solvabilité", desc: "Marges, ratios prudentiels, lecture d'un bilan. Solvency II vs CIMA.", h: "36h" },
    { num: "M03", title: "Souscription IARD et tarification", desc: "Mutualisation, antisélection, tarification a priori et a posteriori.", h: "60h" },
    { num: "M04", title: "Assurance vie et capitalisation", desc: "Tables de mortalité, provisions mathématiques, produits unit-linked.", h: "60h" },
    { num: "M05", title: "Réassurance — proportionnelle et non-proportionnelle", desc: "Traités QS, surplus, XL. Clauses, retentions, brokers.", h: "48h" },
    { num: "M06", title: "Stratégie & management — mémoire de fin d'études", desc: "Encadrement individuel par un cadre praticien et un universitaire.", h: "120h" },
  ];
  return (
    <div>
      <div className="container">
        <div className="page-head" style={{paddingBottom: 0}}>
          <div className="breadcrumb">CPFA · Formations · <span>{f.title}</span></div>
          <div className="detail-hero">
            <div>
              <span className="pill" style={{background: 'rgba(255,255,255,0.12)', color: 'white', borderColor: 'transparent', marginBottom: 16}}>{f.category}</span>
              <h1>{f.title}</h1>
            </div>
          </div>
        </div>
        <div className="detail-grid">
          <div>
            <p className="fs-17 text-mid" style={{lineHeight: 1.55, marginBottom: 32, maxWidth: 720}}>
              {f.desc} Programme rigoureux mêlant cours magistraux, ateliers de cas réels
              en partenariat avec les compagnies de la place, et accompagnement personnalisé
              par un mentor cadre du secteur.
            </p>

            <h3 style={{marginBottom: 24}}>Programme — <em className="italic-emph">six modules</em></h3>
            <div className="module-list">
              {modules.map(m => (
                <div key={m.num} className="module">
                  <div className="module-num">{m.num}</div>
                  <div>
                    <div className="module-title">{m.title}</div>
                    <p className="module-desc">{m.desc}</p>
                  </div>
                  <div className="module-duration">{m.h}</div>
                </div>
              ))}
            </div>

            <div style={{height: 64}}></div>
            <h3 style={{marginBottom: 24}}>Conditions d'admission</h3>
            <div className="col gap-3" style={{maxWidth: 720}}>
              {[
                "Diplôme reconnu CAMES de niveau Bac+4 minimum (toutes disciplines)",
                "Réussite au concours d'entrée — 4 épreuves écrites + entretien",
                "Expérience professionnelle bienvenue mais non obligatoire",
                "Maîtrise du français écrit et oral · niveau B2 anglais souhaitable",
              ].map((t, i) => (
                <div key={i} className="row gap-3" style={{padding: '12px 0', borderBottom: '1px solid var(--line-soft)', alignItems: 'start'}}>
                  <span className="mono fs-13 text-soft" style={{minWidth: 28}}>0{i+1}</span>
                  <span className="fs-15">{t}</span>
                </div>
              ))}
            </div>
          </div>

          <aside className="enroll-card">
            <div>
              <div className="label">Frais de scolarité</div>
              <div className="enroll-price">{f.price.split(' ')[0]} <small>{f.price.split(' ').slice(1).join(' ')}</small></div>
            </div>
            <div className="enroll-stat-row">
              <span className="label">Durée</span>
              <span className="value">{f.duration}</span>
            </div>
            <div className="enroll-stat-row">
              <span className="label">Niveau requis</span>
              <span className="value">{f.level}</span>
            </div>
            <div className="enroll-stat-row">
              <span className="label">Places</span>
              <span className="value">{f.seats} étudiants</span>
            </div>
            <div className="enroll-stat-row">
              <span className="label">Sessions</span>
              <span className="value">{f.sessions}</span>
            </div>
            <div className="enroll-stat-row" style={{borderBottom: '1px solid var(--line-soft)'}}>
              <span className="label">Note alumni</span>
              <span className="value">★ {f.rating} / 5</span>
            </div>
            <button className="btn btn-orange btn-lg" onClick={() => setOpen(true)}>
              Démarrer une candidature <span className="arrow">→</span>
            </button>
            <button className="btn btn-ghost">Télécharger la brochure (PDF)</button>
            <p className="fs-13 text-soft" style={{lineHeight: 1.4}}>
              Paiement échelonné disponible · Wave, Orange Money, virement, carte.
            </p>
          </aside>
        </div>
      </div>
      {open && <EnrollModal f={f} onClose={() => setOpen(false)} />}
    </div>
  );
}

/* Enrollment modal — 3-step flow */
function EnrollModal({ f, onClose }) {
  const [step, setStep] = usePagesState(0);
  const [pay, setPay] = usePagesState('wave');
  const [done, setDone] = usePagesState(false);

  if (done) {
    return (
      <div className="modal-backdrop" onClick={onClose}>
        <div className="modal" onClick={e => e.stopPropagation()}>
          <div className="row" style={{justifyContent: 'center', padding: '24px 0'}}>
            <div style={{width: 72, height: 72, borderRadius: '50%', background: 'var(--orange-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--orange-deep)" strokeWidth="2.5"><path d="M5 12l5 5L20 7"/></svg>
            </div>
          </div>
          <h3 style={{textAlign: 'center'}}>Candidature reçue</h3>
          <p className="fs-15 text-mid" style={{textAlign: 'center', maxWidth: 380, margin: '0 auto'}}>
            Votre dossier a bien été transmis. Vous recevrez un email de confirmation
            sous 48 heures à l'adresse renseignée. Référence : <span className="mono">CPFA-2026-08471</span>
          </p>
          <button className="btn btn-primary btn-lg" onClick={onClose}>Retour à la formation</button>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <span className="eyebrow">Étape {step + 1} sur 3</span>
            <h3 style={{marginTop: 8}}>
              {step === 0 ? 'Vos informations' : step === 1 ? 'Pièces justificatives' : 'Paiement des frais de dossier'}
            </h3>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="steps">
          <div className={"step" + (step >= 0 ? (step > 0 ? ' done' : ' active') : '')}></div>
          <div className={"step" + (step >= 1 ? (step > 1 ? ' done' : ' active') : '')}></div>
          <div className={"step" + (step >= 2 ? ' active' : '')}></div>
        </div>

        {step === 0 && (
          <div className="col gap-4">
            <div className="row gap-3">
              <div style={{flex: 1}}>
                <label className="label">Prénom</label>
                <input className="input" placeholder="Aïssatou" defaultValue="Aïssatou" />
              </div>
              <div style={{flex: 1}}>
                <label className="label">Nom</label>
                <input className="input" placeholder="Ndiaye" defaultValue="Ndiaye" />
              </div>
            </div>
            <div>
              <label className="label">Email</label>
              <input className="input" placeholder="vous@exemple.sn" defaultValue="aissatou.n@gmail.com" />
            </div>
            <div>
              <label className="label">Téléphone</label>
              <input className="input" placeholder="+221 77 000 00 00" defaultValue="+221 77 642 18 09" />
            </div>
            <div>
              <label className="label">Diplôme le plus élevé</label>
              <select className="select" defaultValue="m1">
                <option value="l3">Licence (Bac+3)</option>
                <option value="m1">Master 1 (Bac+4)</option>
                <option value="m2">Master 2 / Ingénieur (Bac+5)</option>
                <option value="phd">Doctorat</option>
              </select>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="col gap-3">
            {[
              { name: "CV à jour", req: true, status: 'attached' },
              { name: "Copie du diplôme et relevés", req: true, status: 'attached' },
              { name: "Lettre de motivation", req: true, status: 'pending' },
              { name: "Pièce d'identité", req: true, status: 'attached' },
              { name: "Justificatif de financement (employeur ou perso)", req: false, status: 'pending' },
            ].map((d, i) => (
              <div key={i} className="row gap-3" style={{padding: '14px 16px', border: '1px solid var(--line)', borderRadius: 8, alignItems: 'center'}}>
                <div style={{width: 36, height: 36, borderRadius: 6, background: 'var(--bg-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M14 3v5h5M5 21V3h9l5 5v13H5z"/></svg>
                </div>
                <div style={{flex: 1}}>
                  <div className="fs-14" style={{fontWeight: 500}}>{d.name} {d.req && <span style={{color: 'var(--orange-deep)'}}>*</span>}</div>
                  <div className="fs-13 text-soft">{d.status === 'attached' ? 'CV_AissatouNdiaye_2026.pdf · 1.2 MB' : 'PDF, JPG ou PNG · max 5 MB'}</div>
                </div>
                {d.status === 'attached'
                  ? <span className="pill pill-success"><span className="dot"></span>Joint</span>
                  : <button className="btn btn-ghost btn-sm">Téléverser</button>
                }
              </div>
            ))}
          </div>
        )}

        {step === 2 && (
          <div className="col gap-4">
            <div className="row" style={{justifyContent: 'space-between', padding: '12px 16px', background: 'var(--bg-soft)', borderRadius: 8}}>
              <div>
                <div className="fs-13 text-soft">Frais de dossier</div>
                <div className="fs-15" style={{fontWeight: 500}}>Concours {f.title}</div>
              </div>
              <div className="serif" style={{fontSize: 32, lineHeight: 1}}>25 000 <small className="mono fs-13 text-soft">FCFA</small></div>
            </div>
            <div>
              <label className="label">Mode de paiement</label>
              <div className="pay-grid">
                {[
                  { id: 'wave', name: 'Wave', desc: 'Mobile money — instantané' },
                  { id: 'om', name: 'Orange Money', desc: 'OM Pay — *144#' },
                  { id: 'card', name: 'Carte bancaire', desc: 'Visa / Mastercard' },
                  { id: 'bank', name: 'Virement', desc: 'CBAO — délai 24-48h' },
                ].map(p => (
                  <div key={p.id} className={"pay-tile" + (pay === p.id ? ' selected' : '')} onClick={() => setPay(p.id)}>
                    <div className={"pay-tile-logo " + p.id}>{p.name.slice(0, p.name === 'Orange Money' ? 2 : 1).toUpperCase()}{p.id === 'om' ? 'M' : ''}</div>
                    <div className="fs-14" style={{fontWeight: 500}}>{p.name}</div>
                    <div className="fs-13 text-soft">{p.desc}</div>
                  </div>
                ))}
              </div>
            </div>
            {pay === 'wave' && (
              <div>
                <label className="label">Numéro Wave</label>
                <input className="input" placeholder="+221 77 000 00 00" defaultValue="+221 77 642 18 09" />
                <p className="fs-13 text-soft" style={{marginTop: 8}}>Vous recevrez une notification Wave sur votre téléphone pour confirmer.</p>
              </div>
            )}
          </div>
        )}

        <div className="row gap-3" style={{justifyContent: 'space-between', borderTop: '1px solid var(--line)', paddingTop: 16}}>
          {step > 0
            ? <button className="btn btn-ghost" onClick={() => setStep(step - 1)}>← Précédent</button>
            : <span></span>
          }
          {step < 2
            ? <button className="btn btn-primary" onClick={() => setStep(step + 1)}>Continuer <span className="arrow">→</span></button>
            : <button className="btn btn-orange" onClick={() => setDone(true)}>Payer 25 000 FCFA <span className="arrow">→</span></button>
          }
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   SEMINAIRES
   ============================================================ */
function Seminaires({ onNav }) {
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>Séminaires</span></div>
        <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', gap: 32}}>
          <h1>Séminaires &<br/><em className="italic-emph">masterclass</em>.</h1>
          <p className="fs-17 text-mid" style={{maxWidth: 380, paddingBottom: 12}}>
            Formats courts et intensifs pour cadres en exercice. Animés par
            des praticiens et universitaires de premier plan.
          </p>
        </div>
      </div>
      <div className="container" style={{paddingBottom: 96}}>
        <div className="event-list">
          {SEMINARS.map((s, i) => (
            <div key={i} className="event">
              <div className="event-date">
                <div className="day">{s.day}</div>
                <div className="month">{s.month} 26</div>
              </div>
              <div>
                <h4>{s.title}</h4>
                <p className="event-desc fs-14 text-mid" style={{marginTop: 6}}>{s.desc}</p>
                <div className="row gap-2" style={{marginTop: 12}}>
                  <span className="pill">{s.duration}</span>
                  <span className={"pill " + (s.seats.includes('COMPLET') ? 'pill-warning' : 'pill-orange')}>{s.seats}</span>
                </div>
              </div>
              <div className="event-meta">
                <span>{s.price}</span>
              </div>
              <button className="btn btn-ghost btn-sm">
                Détails <span className="arrow">→</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CONCOURS
   ============================================================ */
function Concours({ onNav }) {
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>Concours d'entrée</span></div>
        <h1>Concours d'entrée<br/><em className="italic-emph">2026 — 2027.</em></h1>
      </div>
      <div className="container" style={{paddingBottom: 96}}>
        <div className="concours-card" style={{marginBottom: 48}}>
          <div>
            <span className="eyebrow" style={{marginBottom: 16}}>Clôture des candidatures dans</span>
            <Countdown />
            <div className="row gap-3">
              <button className="btn btn-orange btn-lg">Déposer mon dossier <span className="arrow">→</span></button>
              <button className="btn btn-ghost btn-lg">Annales 2018-2025</button>
            </div>
          </div>
          <div>
            <h3 style={{marginBottom: 16}}>Quatre épreuves, une <em className="italic-emph">trajectoire</em>.</h3>
            <div className="col gap-4">
              {[
                { num: "01", title: "Culture économique et financière", desc: "QCM 90 minutes · coefficient 2" },
                { num: "02", title: "Mathématiques financières & probabilités", desc: "Composition 3 heures · coefficient 3" },
                { num: "03", title: "Anglais des affaires", desc: "Compréhension écrite 60 minutes · coefficient 1" },
                { num: "04", title: "Entretien de motivation", desc: "Jury de 3 personnes · 25 minutes · coefficient 2" },
              ].map(e => (
                <div key={e.num} className="row gap-4" style={{paddingTop: 16, borderTop: '1px solid var(--line)'}}>
                  <span className="mono fs-13 text-soft" style={{minWidth: 28}}>{e.num}</span>
                  <div>
                    <div className="fs-15" style={{fontWeight: 500, marginBottom: 4}}>{e.title}</div>
                    <div className="fs-13 text-soft">{e.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="row gap-4">
          {[
            { num: "30 août", label: "Clôture inscriptions", price: "Dépôt en ligne" },
            { num: "12 sept", label: "Épreuves écrites", price: "Centre Dakar" },
            { num: "20 sept", label: "Entretiens", price: "Convocation par email" },
            { num: "25 sept", label: "Résultats", price: "Affichage public" },
          ].map((s, i) => (
            <div key={i} className="card" style={{flex: 1}}>
              <div className="serif" style={{fontSize: 36, lineHeight: 1, marginBottom: 8}}>{s.num}</div>
              <div className="fs-14" style={{fontWeight: 500, marginBottom: 4}}>{s.label}</div>
              <div className="fs-13 text-soft">{s.price}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  Home, Formations, FormationDetail, Seminaires, Concours,
  FormationCard, Book, FORMATIONS, BOOKS, TESTIMONIALS, SEMINARS,
});
