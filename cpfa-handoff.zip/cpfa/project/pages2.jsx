/* CPFA — Pages 2: Bibliothèque, Member, Admin, About, Contact */

const { useState: usePages2State } = React;

const MEMBER_LOANS = [
  { title: "Traité de Droit des Assurances CIMA", author: "Mamadou Diop", due: "12 mai", late: false, cover: 'navy' },
  { title: "Microassurance en Afrique", author: "BCEAO / ILO", due: "18 mai", late: false, cover: 'cream' },
  { title: "Solvabilité II", author: "C. Bellando", due: "06 mai", late: true, cover: 'olive' },
  { title: "Réassurance non-vie", author: "Klein & Sow", due: "23 mai", late: false, cover: 'ink' },
];

const MEMBER_INSCRIPTIONS = [
  { title: "MBA en Management de l'Assurance", session: "Promotion 2026", status: "Admis · à confirmer", color: "pill-success" },
  { title: "Workshop Solvabilité", session: "08-10 juillet 2026", status: "Confirmé", color: "pill-orange" },
  { title: "Concours d'entrée 2026", session: "Épreuves 12 sept", status: "En attente", color: "pill" },
];

/* ============================================================
   BIBLIOTHÈQUE
   ============================================================ */
function Bibliotheque({ onNav }) {
  const [filter, setFilter] = usePages2State("Tout");
  const cats = ["Tout", "Droit", "Actuariat", "Réassurance", "Gestion", "Études CIMA", "Mémoires"];
  const all = [...BOOKS, ...BOOKS]; // duplicate for fuller grid
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>Bibliothèque</span></div>
        <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', gap: 32}}>
          <h1>Bibliothèque<br/><em className="italic-emph">spécialisée</em>.</h1>
          <p className="fs-17 text-mid" style={{maxWidth: 420, paddingBottom: 12}}>
            3 200 références — ouvrages techniques, mémoires d'étudiants,
            études CIMA et publications professionnelles. Accès libre aux abonnés.
          </p>
        </div>
      </div>

      <div className="container">
        <div className="row gap-4" style={{marginBottom: 32, alignItems: 'end'}}>
          <div style={{flex: 1, maxWidth: 460}}>
            <label className="label">Recherche</label>
            <input className="input" placeholder="Titre, auteur, sujet, ISBN…" />
          </div>
          <div style={{minWidth: 180}}>
            <label className="label">Type de support</label>
            <select className="select" defaultValue="all">
              <option value="all">Tous les supports</option>
              <option>Ouvrages</option>
              <option>Périodiques</option>
              <option>Mémoires</option>
              <option>Études</option>
            </select>
          </div>
          <div style={{minWidth: 180}}>
            <label className="label">Disponibilité</label>
            <select className="select" defaultValue="all">
              <option value="all">Tout</option>
              <option>Disponible immédiatement</option>
              <option>Sur réservation</option>
            </select>
          </div>
          <button className="btn btn-primary">Chercher</button>
        </div>

        <div className="filter-bar">
          {cats.map(c => (
            <button key={c}
              className={"filter-chip" + (c === filter ? " active" : "")}
              onClick={() => setFilter(c)}>
              {c}
            </button>
          ))}
        </div>

        <div className="row" style={{justifyContent: 'space-between', marginBottom: 24}}>
          <span className="text-soft fs-13 mono">{all.length} résultats · trié par nouveauté</span>
          <div className="row gap-2">
            <button className="filter-chip active">Couvertures</button>
            <button className="filter-chip">Liste</button>
          </div>
        </div>

        <div className="book-grid" style={{marginBottom: 96}}>
          {all.slice(0, 15).map((b, i) => <Book key={i} b={b} />)}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   ESPACE ABONNÉ
   ============================================================ */
function Member({ onNav }) {
  const [tab, setTab] = usePages2State('overview');
  return (
    <div>
      <div className="container">
        <div className="page-head" style={{paddingBottom: 32}}>
          <div className="breadcrumb">CPFA · <span>Espace abonné</span></div>
          <div className="row" style={{justifyContent: 'space-between', alignItems: 'end'}}>
            <div>
              <h1 style={{fontSize: 'clamp(40px, 5vw, 64px)'}}>
                Bienvenue, <em className="italic-emph">Aïssatou</em>.
              </h1>
              <p className="fs-15 text-mid" style={{marginTop: 12}}>Promotion MBA 2026 · Abonnée bibliothèque jusqu'au 30 sept 2027</p>
            </div>
            <div className="row gap-2">
              <span className="pill pill-success"><span className="dot"></span>Compte actif</span>
            </div>
          </div>
        </div>

        <div className="member-shell">
          <aside className="side-nav">
            <div className="side-nav-title">Mon espace</div>
            <a className={"item" + (tab === 'overview' ? ' active' : '')} onClick={() => setTab('overview')}>
              Tableau de bord
            </a>
            <a className={"item" + (tab === 'card' ? ' active' : '')} onClick={() => setTab('card')}>
              Ma carte
            </a>
            <a className={"item" + (tab === 'loans' ? ' active' : '')} onClick={() => setTab('loans')}>
              Mes prêts <span className="count">4</span>
            </a>
            <a className={"item" + (tab === 'inscriptions' ? ' active' : '')} onClick={() => setTab('inscriptions')}>
              Mes inscriptions <span className="count">3</span>
            </a>
            <div className="side-nav-title">Réservations</div>
            <a className="item">Files d'attente <span className="count">1</span></a>
            <a className="item">Réservations à venir</a>
            <div className="side-nav-title">Compte</div>
            <a className="item">Paramètres</a>
            <a className="item">Facturation</a>
            <a className="item" style={{color: 'var(--danger)'}}>Déconnexion</a>
          </aside>

          <div>
            {tab === 'overview' && <MemberOverview />}
            {tab === 'card' && <MemberCardView />}
            {tab === 'loans' && <MemberLoans />}
            {tab === 'inscriptions' && <MemberInscriptions onNav={onNav} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function MemberCardLarge() {
  return (
    <div className="member-card">
      <div className="member-card-top">
        <div>
          <div className="member-card-name">Aïssatou Ndiaye</div>
          <div className="member-card-num">CPFA · 2024 · 0871</div>
        </div>
        <div style={{width: 44, height: 44, position: 'relative', flexShrink: 0}}>
          <LogoMark size={44} />
        </div>
      </div>
      <div className="member-card-bottom">
        <div>
          <div className="label">Promotion</div>
          <div className="value">MBA 2026</div>
        </div>
        <div>
          <div className="label">Statut</div>
          <div className="value">Abonnée</div>
        </div>
        <div>
          <div className="label">Valide jusqu'au</div>
          <div className="value">30/09/27</div>
        </div>
      </div>
    </div>
  );
}

function MemberOverview() {
  return (
    <div className="col gap-6">
      <div className="row gap-5" style={{display: 'grid', gridTemplateColumns: '1.2fr 1fr'}}>
        <MemberCardLarge />
        <div className="card" style={{display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
          <div>
            <div className="label">Prochain rendez-vous</div>
            <div className="serif" style={{fontSize: 32, lineHeight: 1.05, margin: '12px 0'}}>
              Workshop<br/>Solvabilité II
            </div>
            <div className="fs-13 text-soft">Animé par Frédéric Planchet</div>
          </div>
          <div className="row gap-2" style={{marginTop: 16}}>
            <span className="pill pill-orange">08-10 Juillet</span>
            <span className="pill">Salle B204</span>
          </div>
        </div>
      </div>

      <div>
        <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', marginBottom: 16}}>
          <h3>Prêts en cours</h3>
          <a className="btn-link fs-13">Voir tout →</a>
        </div>
        <LoanList items={MEMBER_LOANS.slice(0, 3)} />
      </div>

      <div>
        <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', marginBottom: 16}}>
          <h3>Mes inscriptions</h3>
          <a className="btn-link fs-13">Voir tout →</a>
        </div>
        <div className="col gap-3">
          {MEMBER_INSCRIPTIONS.map((i, k) => (
            <div key={k} className="card row gap-4" style={{alignItems: 'center', padding: 18}}>
              <div style={{flex: 1}}>
                <div className="fs-15" style={{fontWeight: 500}}>{i.title}</div>
                <div className="fs-13 text-soft" style={{marginTop: 4}}>{i.session}</div>
              </div>
              <span className={"pill " + i.color}><span className="dot"></span>{i.status}</span>
              <button className="btn btn-ghost btn-sm">Détails →</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MemberCardView() {
  return (
    <div className="col gap-5">
      <h3>Ma carte d'abonnée</h3>
      <p className="fs-15 text-mid" style={{maxWidth: 560}}>
        Présentez-la à l'accueil de la bibliothèque ou scannez le QR code à l'entrée
        des séminaires. Carte virtuelle uniquement — Wallet Apple/Google compatible.
      </p>
      <div style={{maxWidth: 480}}>
        <MemberCardLarge />
      </div>
      <div className="row gap-3">
        <button className="btn btn-primary">Ajouter à Apple Wallet</button>
        <button className="btn btn-ghost">Télécharger PDF</button>
      </div>
      <div className="card" style={{maxWidth: 560}}>
        <div className="label">Avantages abonnement</div>
        <div className="col gap-3" style={{marginTop: 16}}>
          {[
            "Emprunt jusqu'à 5 ouvrages simultanément",
            "Accès au fonds numérique CIMA + études BCEAO",
            "Tarif réduit -30% sur tous les séminaires",
            "Invitations aux journées alumni",
          ].map((t, i) => (
            <div key={i} className="row gap-3" style={{alignItems: 'start'}}>
              <span style={{color: 'var(--orange)', fontFamily: 'var(--mono)'}}>✓</span>
              <span className="fs-14">{t}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MemberLoans() {
  return (
    <div className="col gap-5">
      <div className="row" style={{justifyContent: 'space-between', alignItems: 'end'}}>
        <h3>Mes prêts en cours</h3>
        <button className="btn btn-ghost btn-sm">Historique des prêts</button>
      </div>
      <div className="row gap-3">
        <div className="card" style={{flex: 1}}>
          <div className="label">En cours</div>
          <div className="serif" style={{fontSize: 40, marginTop: 8}}>4 / 5</div>
        </div>
        <div className="card" style={{flex: 1}}>
          <div className="label">À rendre cette semaine</div>
          <div className="serif" style={{fontSize: 40, marginTop: 8}}>2</div>
        </div>
        <div className="card" style={{flex: 1, borderColor: 'var(--danger)'}}>
          <div className="label" style={{color: 'var(--danger)'}}>En retard</div>
          <div className="serif" style={{fontSize: 40, marginTop: 8, color: 'var(--danger)'}}>1</div>
        </div>
      </div>
      <LoanList items={MEMBER_LOANS} />
      <div>
        <h3 style={{marginBottom: 16}}>Recommandations pour vous</h3>
        <div className="book-grid" style={{gridTemplateColumns: 'repeat(4, 1fr)'}}>
          {BOOKS.slice(2, 6).map((b, i) => <Book key={i} b={b} />)}
        </div>
      </div>
    </div>
  );
}

function LoanList({ items }) {
  return (
    <div className="loan-list">
      {items.map((l, i) => (
        <div key={i} className="loan-item">
          <div className={"loan-cover " + l.cover}></div>
          <div>
            <div className="loan-title">{l.title}</div>
            <div className="loan-author">{l.author}</div>
          </div>
          <span className={"pill " + (l.late ? 'pill-warning' : '')}>
            {l.late ? 'En retard' : 'En cours'}
          </span>
          <div className={"loan-due" + (l.late ? ' loan-due-late' : '')}>
            <div className="text-soft fs-13" style={{textTransform: 'uppercase', letterSpacing: '0.04em', fontSize: 10}}>À rendre</div>
            <div style={{fontSize: 14, marginTop: 2}}>{l.due}</div>
          </div>
          <button className="btn btn-ghost btn-sm">Prolonger</button>
        </div>
      ))}
    </div>
  );
}

function MemberInscriptions({ onNav }) {
  return (
    <div className="col gap-5">
      <div className="row" style={{justifyContent: 'space-between', alignItems: 'end'}}>
        <h3>Mes inscriptions & candidatures</h3>
        <button className="btn btn-primary btn-sm" onClick={() => onNav('formations')}>
          Nouvelle inscription <span className="arrow">→</span>
        </button>
      </div>
      {[
        { title: "MBA en Management de l'Assurance", session: "Promotion 2026 · Octobre", status: "Admise · à confirmer", color: "pill-success", price: "3 500 000 FCFA", paid: "350 000", action: "Confirmer ma place", actionStyle: "btn-orange" },
        { title: "Workshop Solvabilité II", session: "08-10 juillet 2026", status: "Inscription confirmée", color: "pill-orange", price: "350 000 FCFA", paid: "350 000", action: "Voir détails", actionStyle: "btn-ghost" },
        { title: "Concours d'entrée 2026", session: "Épreuves 12 sept · Centre Dakar", status: "Dossier en cours d'examen", color: "pill", price: "25 000 FCFA", paid: "25 000", action: "Suivre l'instruction", actionStyle: "btn-ghost" },
      ].map((i, k) => (
        <div key={k} className="card" style={{padding: 24}}>
          <div className="row" style={{justifyContent: 'space-between', alignItems: 'start', marginBottom: 16}}>
            <div>
              <div className="serif" style={{fontSize: 28, lineHeight: 1.1, marginBottom: 6}}>{i.title}</div>
              <div className="fs-13 text-soft">{i.session}</div>
            </div>
            <span className={"pill " + i.color}><span className="dot"></span>{i.status}</span>
          </div>
          <div className="divider" style={{margin: '16px 0'}}></div>
          <div className="row" style={{justifyContent: 'space-between', alignItems: 'center'}}>
            <div className="row gap-6">
              <div>
                <div className="label">Total</div>
                <div className="fs-15" style={{fontWeight: 500, marginTop: 4}}>{i.price}</div>
              </div>
              <div>
                <div className="label">Réglé</div>
                <div className="fs-15" style={{fontWeight: 500, marginTop: 4}}>{i.paid} FCFA</div>
              </div>
              <div>
                <div className="label">Référence</div>
                <div className="fs-15 mono" style={{marginTop: 4}}>CPFA-2026-0{8471 + k}</div>
              </div>
            </div>
            <button className={"btn " + i.actionStyle}>{i.action} <span className="arrow">→</span></button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============================================================
   ABOUT
   ============================================================ */
function About({ onNav }) {
  return (
    <div>
      <div className="container page-head">
        <div className="breadcrumb">CPFA · <span>À propos</span></div>
        <h1 style={{maxWidth: 1100, fontSize: 'clamp(56px, 6.5vw, 96px)'}}>
          Trente ans à former l'<em className="italic-emph">orbite</em> de l'assurance ouest-africaine.
        </h1>
      </div>
      <div className="container">
        <div className="row gap-7" style={{display: 'grid', gridTemplateColumns: '1.4fr 1fr', marginBottom: 96}}>
          <div className="col gap-5">
            <p className="fs-17 text-mid" style={{lineHeight: 1.55}}>
              Fondé en 1996 sous l'impulsion conjointe du Ministère des Finances
              et de la Fédération Sénégalaise des Sociétés d'Assurances, le CPFA
              est devenu en trois décennies <em className="italic-emph">la référence académique régionale</em> pour
              les métiers techniques et managériaux de l'assurance.
            </p>
            <p className="fs-17 text-mid" style={{lineHeight: 1.55}}>
              Plus de 4 200 diplômés exercent aujourd'hui dans les compagnies de la zone
              CIMA, à la Direction des Assurances, dans les cabinets de courtage, et
              jusqu'aux institutions panafricaines comme la CICA-Re et Africa-Re.
            </p>
            <div className="row gap-3">
              <button className="btn btn-primary">Rapport annuel 2025 (PDF)</button>
              <button className="btn btn-ghost" onClick={() => onNav('contact')}>Nous écrire</button>
            </div>
          </div>
          <div className="card" style={{padding: 32}}>
            <div className="label">Gouvernance</div>
            <div className="col gap-4" style={{marginTop: 16}}>
              {[
                { role: "Direction générale", name: "Pr Ousmane Diagne", note: "Agrégé droit privé, UCAD" },
                { role: "Direction académique", name: "Dr Fatou Sow", note: "PhD Actuariat, ISFA Lyon" },
                { role: "Direction des programmes", name: "M. Cheikh Bâ", note: "Ex-DG NSIA Sénégal" },
                { role: "Conseil pédagogique", name: "12 cadres du secteur", note: "Représentants compagnies + régulateur" },
              ].map((g, i) => (
                <div key={i} style={{paddingTop: 16, borderTop: i ? '1px solid var(--line)' : 'none'}}>
                  <div className="label">{g.role}</div>
                  <div className="fs-15" style={{fontWeight: 500, marginTop: 4}}>{g.name}</div>
                  <div className="fs-13 text-soft" style={{marginTop: 2}}>{g.note}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <h2 style={{marginBottom: 32}}>Partenaires <em className="italic-emph">institutionnels</em>.</h2>
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 0, border: '1px solid var(--line)', borderRadius: 14, overflow: 'hidden', marginBottom: 96}}>
          {["CIMA", "BCEAO", "FSSA", "CICA-Re", "Africa-Re", "FANAF", "ISFA Lyon", "ENASS Paris", "UCAD", "Inst. Actuaires", "AFRA", "CIPRES"].map((p, i) => (
            <div key={i} style={{padding: '32px 24px', borderRight: (i+1) % 6 ? '1px solid var(--line)' : 'none', borderTop: i >= 6 ? '1px solid var(--line)' : 'none', textAlign: 'center'}}>
              <div className="serif" style={{fontSize: 24, lineHeight: 1.1}}>{p}</div>
            </div>
          ))}
        </div>

        <div style={{marginBottom: 96}}>
          <h2 style={{marginBottom: 32}}>Trois décennies, <em className="italic-emph">en chiffres</em>.</h2>
          <div className="stat-row">
            <div className="stat">
              <div className="stat-value">1996</div>
              <div className="stat-label">Année de création</div>
            </div>
            <div className="stat">
              <div className="stat-value">4 200<sup>+</sup></div>
              <div className="stat-label">Diplômés</div>
            </div>
            <div className="stat">
              <div className="stat-value">86</div>
              <div className="stat-label">Intervenants experts</div>
            </div>
            <div className="stat">
              <div className="stat-value">14</div>
              <div className="stat-label">Pays africains</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   ADMIN DASHBOARD (preview)
   ============================================================ */
function AdminDashboard({ onNav }) {
  return (
    <div>
      <div style={{background: 'var(--ink)', color: 'var(--bg)', padding: '12px 0'}}>
        <div className="container row" style={{justifyContent: 'space-between', alignItems: 'center'}}>
          <span className="mono" style={{fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.7}}>
            ⚠ Aperçu administrateur · données fictives
          </span>
          <button className="btn btn-ghost btn-sm" onClick={() => onNav('home')} style={{color: 'var(--bg)', borderColor: 'rgba(255,255,255,0.2)'}}>
            ← Retour au site public
          </button>
        </div>
      </div>
      <div className="admin-shell">
        <aside className="admin-side">
          <div style={{padding: '8px 12px 16px', borderBottom: '1px solid oklch(28% 0.06 258)', marginBottom: 8}}>
            <div className="row gap-3" style={{alignItems: 'center'}}>
              <LogoMark size={28} />
              <div>
                <div className="fs-13" style={{color: 'white', fontWeight: 500}}>CPFA Admin</div>
                <div className="mono" style={{fontSize: 9, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'oklch(60% 0.02 258)'}}>v2.4 · staging</div>
              </div>
            </div>
          </div>
          <h5>Pilotage</h5>
          <a className="item active">Vue d'ensemble</a>
          <a className="item">Statistiques</a>
          <a className="item">Rapports</a>
          <h5>Gestion</h5>
          <a className="item">Inscriptions <span className="count">23</span></a>
          <a className="item">Candidatures <span className="count">147</span></a>
          <a className="item">Formations</a>
          <a className="item">Séminaires</a>
          <h5>Bibliothèque</h5>
          <a className="item">Catalogue <span className="count">3.2k</span></a>
          <a className="item">Prêts en cours <span className="count">281</span></a>
          <a className="item">Retards <span className="count">12</span></a>
          <h5>Contenus</h5>
          <a className="item">Pages publiques</a>
          <a className="item">Médias S3</a>
          <h5>Système</h5>
          <a className="item">Utilisateurs</a>
          <a className="item">Paiements Wave/OM</a>
          <a className="item">Logs & jobs</a>
        </aside>
        <main className="admin-main">
          <div className="row" style={{justifyContent: 'space-between', alignItems: 'end', marginBottom: 32}}>
            <div>
              <div className="breadcrumb">Admin · <span>Vue d'ensemble</span></div>
              <h2 style={{fontSize: 'clamp(36px, 4vw, 52px)', marginTop: 8}}>Bonjour, <em className="italic-emph">Pr Diagne</em>.</h2>
            </div>
            <div className="row gap-2">
              <select className="select" style={{width: 200}} defaultValue="2026">
                <option>Année 2026</option>
                <option>Année 2025</option>
              </select>
              <button className="btn btn-primary">Exporter CSV</button>
            </div>
          </div>

          <div className="kpi-row">
            <div className="kpi">
              <div className="label">Inscriptions actives</div>
              <div className="value">238</div>
              <div className="delta up">↑ +18 cette semaine</div>
            </div>
            <div className="kpi">
              <div className="label">Candidatures concours</div>
              <div className="value">147</div>
              <div className="delta up">↑ +42 vs 2025</div>
            </div>
            <div className="kpi">
              <div className="label">Recettes mensuelles</div>
              <div className="value">38,4M</div>
              <div className="delta up">↑ +12% MoM · FCFA</div>
            </div>
            <div className="kpi">
              <div className="label">Taux d'insertion 2024</div>
              <div className="value">96%</div>
              <div className="delta up">↑ +3 pts</div>
            </div>
          </div>

          <div className="admin-grid-2">
            <div className="panel">
              <div className="panel-head">
                <h4>Candidatures à valider</h4>
                <button className="btn btn-ghost btn-sm">Tout voir</button>
              </div>
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Réf</th>
                    <th>Candidat</th>
                    <th>Programme</th>
                    <th>Statut</th>
                    <th>Reçue</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { ref: "0871", n: "Aïssatou Ndiaye", p: "MBA Mgmt Assurance", s: "À valider", c: "warning", d: "il y a 2h" },
                    { ref: "0870", n: "Jean-Marc Sène", p: "Licence Pro", s: "Pièces à compléter", c: "", d: "il y a 5h" },
                    { ref: "0869", n: "Fatima Ba", p: "Cert. Bancassurance", s: "Validée", c: "success", d: "hier" },
                    { ref: "0868", n: "Ibrahim Diallo", p: "Init. Actuariat", s: "À valider", c: "warning", d: "hier" },
                    { ref: "0867", n: "Awa Sarr", p: "MBA Mgmt Assurance", s: "Validée", c: "success", d: "2 jours" },
                    { ref: "0866", n: "Moussa Cissé", p: "Cert. Microassurance", s: "Refusée", c: "", d: "3 jours" },
                  ].map((r, i) => (
                    <tr key={i}>
                      <td className="mono text-soft">CPFA-{r.ref}</td>
                      <td style={{fontWeight: 500}}>{r.n}</td>
                      <td className="text-mid">{r.p}</td>
                      <td><span className={"pill " + (r.c ? 'pill-' + r.c : '')}>{r.s}</span></td>
                      <td className="text-soft mono fs-13">{r.d}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="panel">
              <div className="panel-head">
                <h4>Inscriptions par programme</h4>
                <span className="text-soft fs-13 mono">Promo 2026</span>
              </div>
              <div style={{padding: 24}} className="col gap-4">
                {[
                  { name: "MBA Management Assurance", val: 28, max: 28, pct: 100 },
                  { name: "Licence Pro Assurance", val: 47, max: 60, pct: 78 },
                  { name: "Cert. Bancassurance", val: 31, max: 32, pct: 97 },
                  { name: "Init. Actuariat", val: 18, max: 24, pct: 75 },
                  { name: "Cert. Microassurance", val: 22, max: 40, pct: 55 },
                ].map((b, i) => (
                  <div key={i}>
                    <div className="row" style={{justifyContent: 'space-between', marginBottom: 6}}>
                      <span className="fs-13">{b.name}</span>
                      <span className="mono fs-13 text-soft">{b.val}/{b.max}</span>
                    </div>
                    <div style={{height: 6, background: 'var(--bg-soft)', borderRadius: 3, overflow: 'hidden'}}>
                      <div style={{height: '100%', width: b.pct + '%', background: b.pct >= 90 ? 'var(--orange)' : 'var(--ink)'}}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div style={{height: 24}}></div>

          <div className="admin-grid-2">
            <div className="panel">
              <div className="panel-head">
                <h4>Activité bibliothèque · 7 derniers jours</h4>
              </div>
              <div style={{padding: 24}}>
                <Sparkline />
              </div>
            </div>
            <div className="panel">
              <div className="panel-head">
                <h4>Paiements Wave / Orange Money</h4>
                <span className="pill pill-success"><span className="dot"></span>API up</span>
              </div>
              <table className="tbl">
                <tbody>
                  {[
                    { ref: "WAV-2891", amt: "350 000", who: "A. Ndiaye", t: "Workshop Solvabilité", s: "ok" },
                    { ref: "OM-7714", amt: "25 000", who: "I. Diallo", t: "Concours 2026", s: "ok" },
                    { ref: "WAV-2890", amt: "1 200 000", who: "M. Cissé", t: "Licence Pro · 1ère tranche", s: "ok" },
                    { ref: "OM-7713", amt: "180 000", who: "F. Ba", t: "Sémin. Réforme CIMA", s: "pending" },
                  ].map((p, i) => (
                    <tr key={i}>
                      <td className="mono text-soft fs-13">{p.ref}</td>
                      <td>
                        <div className="fs-14" style={{fontWeight: 500}}>{p.who}</div>
                        <div className="fs-13 text-soft">{p.t}</div>
                      </td>
                      <td className="serif" style={{fontSize: 18, textAlign: 'right'}}>{p.amt}<span className="mono fs-13 text-soft" style={{marginLeft: 4}}>FCFA</span></td>
                      <td><span className={"pill " + (p.s === 'ok' ? 'pill-success' : 'pill-warning')}>{p.s === 'ok' ? 'Réglé' : 'Attente'}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function Sparkline() {
  // Simple SVG bar chart
  const data = [42, 58, 51, 67, 73, 39, 81];
  const days = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
  const max = Math.max(...data);
  return (
    <div>
      <div className="row gap-6" style={{marginBottom: 16}}>
        <div>
          <div className="label">Prêts émis</div>
          <div className="serif" style={{fontSize: 36, marginTop: 4}}>411</div>
        </div>
        <div>
          <div className="label">Retours</div>
          <div className="serif" style={{fontSize: 36, marginTop: 4}}>389</div>
        </div>
        <div>
          <div className="label">Réservations</div>
          <div className="serif" style={{fontSize: 36, marginTop: 4}}>62</div>
        </div>
      </div>
      <div style={{display: 'flex', gap: 12, alignItems: 'end', height: 140, marginTop: 24}}>
        {data.map((v, i) => (
          <div key={i} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8}}>
            <div style={{flex: 1, display: 'flex', alignItems: 'end', width: '100%'}}>
              <div style={{
                width: '100%',
                height: (v / max * 100) + '%',
                background: i === data.length - 1 ? 'var(--orange)' : 'var(--ink)',
                borderRadius: '4px 4px 0 0',
                position: 'relative'
              }}>
                <div className="mono" style={{
                  position: 'absolute',
                  top: -22,
                  left: '50%',
                  transform: 'translateX(-50%)',
                  fontSize: 11,
                  color: 'var(--ink-soft)'
                }}>{v}</div>
              </div>
            </div>
            <div className="mono fs-13 text-soft">{days[i]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  Bibliotheque, Member, About, AdminDashboard,
});
